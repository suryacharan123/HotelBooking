import {useState} from 'react'
import axios from 'axios';
import { compareSync } from 'bcryptjs';
import { userLoginContext } from './userLoginContext';
function UserContextProvider({children}) {

    let[currentUser,setCurrentUser]=useState({})
    let[userLoginStatus,setUserLoginStatus]=useState(false)
    let [error,setError]=useState('')

    async function onUserLogin(userCredObj) {
        let res = await axios.post(
          `http://localhost:4000/user-api/login`,
          userCredObj
        );
       console.log(res);
          if(res.status === 200){
            // Login Succes Procudre
           let token= res.data.token
           localStorage.setItem('token',token)
           let user=res.data.user
           setCurrentUser(user)
            setUserLoginStatus(true)
          }
          else{

          }
       //       let usersList = res.data;
  //   console.log(usersList)
  // let userData=usersList.user
  //       if (usersList.length === 0) {
  //         setError("Invalid Username");
  //       } else {
  //         let result = compareSync(userData.password, userData[0].password);
  //         if (result === false) {
  //           setError("Invalid Password");
  //         } else {
  //           setCurrentUser(usersList[0])
  //           setUserLoginStatus(true)
  //         }
        // }
      }
  return (
    <div>
        <userLoginContext.Provider
        value={[currentUser,setCurrentUser,userLoginStatus,setUserLoginStatus,onUserLogin]}
        >{children}</userLoginContext.Provider>
    </div>
  )
}

export default UserContextProvider

