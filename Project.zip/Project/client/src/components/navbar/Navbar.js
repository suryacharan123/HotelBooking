import React, { useContext } from "react";
import "./Navbar.css";
import { userLoginContext } from "../../contexts/userLoginContext";

function Navbar() {
  const [, setCurrentUser, userLoginStatus, setUserLoginStatus] =
    useContext(userLoginContext);

  const handleLogout = () => {
    // Perform any logout actions and update the user login status
    setCurrentUser({});
    setUserLoginStatus(false);
  };

  return (
    <nav
      className="navbar navbar-expand-lg bg-body-tertiary"
      data-bs-theme="dark"
    >
      <div className="container-fluid">
        <a className="navbar-brand" href="/">
          My Rooms
        </a>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ml-auto">
            {userLoginStatus ? (
              // If user is logged in, show "Logout"
              <>
                <li className="nav-item">
                  <a
                    href="/login"
                    className="nav-link btn"
                    onClick={handleLogout}
                  >
                    Logout
                  </a>
                </li>
              </>
            ) : (
              // If user is not logged in, show "Register" and "Login"
              <>
                <li className="nav-item">
                  <a className="nav-link" href="/">
                    Home
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/register">
                    Register
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/login">
                    Login
                  </a>
                </li>
              </>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
