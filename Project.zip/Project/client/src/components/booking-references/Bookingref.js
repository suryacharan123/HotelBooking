import React from "react";
import "./Bookingref.css";
import Bookingreff from "../Bookingreff";
import Navbar from "../navbar/Navbar";
function Bookingref() {
  return (
    <div>
      <div className="refe">
        <Bookingreff area="Hyderabad" state="Telangana"></Bookingreff>
        <Bookingreff area="Mumbai" state="Maharastra"></Bookingreff>{" "}
        <Bookingreff area="Chennai" state="Tamil Nadu"></Bookingreff>
      </div>
      <div></div>
    </div>
  );
}

export default Bookingref;
