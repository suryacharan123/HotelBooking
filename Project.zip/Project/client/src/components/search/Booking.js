import React, { useContext, useEffect, useState } from "react";
import axios from "axios";
import { DateRange } from "react-date-range";
import { userLoginContext } from "../../contexts/userLoginContext";
import "react-date-range/dist/styles.css";
import "react-date-range/dist/theme/default.css";
import "./Booking.css";
import { useNavigate } from "react-router-dom";
import { differenceInDays, format } from "date-fns";

function Booking() {
  // Define necessary state and context
  let navigate = useNavigate();
  let [currentUser, userLoginStatus] = useContext(userLoginContext);
  let [location, setLocation] = useState("");
  let [values, setValues] = useState([]);
  let [openDate, setopenDate] = useState(false);
  let [date, setDate] = useState([
    {
      startDate: new Date(),
      endDate: new Date(),
      key: "selection",
    },
  ]);
  let [numberOfDays, setNumberofdays] = useState(0);
  let [openOptions, setopenOptions] = useState(false);
  let [options, setOptions] = useState({
    adult: 1,
    children: 0,
    room: 1,
  });

  // useEffect for calculating the number of days
  useEffect(() => {
    let days = differenceInDays(date[0].endDate, date[0].startDate) + 1;
    setNumberofdays(days);
  }, [date]);

  // Function to find hotels based on the entered location
  async function findLocation(e) {
    e.preventDefault();

    try {
      console.log("Here");
      let res = await axios.get('http://localhost:4000/hotel-api/hotels');
      console.log(res)
      let hotelList = res.data.payload
      setValues(hotelList);
      // Filter hotels based on the location
      let filteredHotels = hotelList.filter(
        (ele) => ele.location.toLowerCase() === location.toLowerCase()
      );

      if (filteredHotels.length > 0) {
        // Pass hotels, date, and options to RoomList
        navigate("/roomlist", {
          state: {
            hotels: filteredHotels,
            date: date,
            options: options,
            numberOfDays: numberOfDays,
          },
        });
      } else {
        console.log("No hotels found for the selected location");
      }

      console.log(res.data);
    } catch (error) {
      console.log(error);
    }
  }
  if (!userLoginStatus) {
    // If not logged in, display a message or redirect to login page
    return <p>Please log in to register your hotel.</p>;
  }
  // Function to handle options
  function handleOptions(name, operations) {
    setOptions((prev) => {
      return {
        ...prev,
        [name]: operations === "i" ? options[name] + 1 : options[name] - 1,
      };
    });
  }

  // Return the JSX for the Booking component
  return (
    <div className="back">
      <div>
        <p className="usname">Welcome, {currentUser.name}</p>
        <div className="homecon">
          <p>
            If you want to register your hotel on our website{" "}
            <a
              href="/hotels"
              onClick={(e) => {
                e.preventDefault();
                navigate("/hotels");
              }}
            >
              Click Here
            </a>
          </p>
        </div>
        <div className="hs">
          <div>
            <i className="fa-solid fa-location-dot"></i>
            <input
              placeholder="Location"
              className="hsinput"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
          </div>
          <div className="date-picker-container">
            <i className="fa-regular fa-calendar"></i>
            <span onClick={() => setopenDate(!openDate)} className="hstext">
              {` ${format(date[0].startDate, "dd/MM/yyyy")} to ${format(
                date[0].endDate,
                "dd/MM/yyyy"
              )} `}
              ({numberOfDays} days)
            </span>
            {openDate && (
              <DateRange
                editableDateInputs={true}
                onChange={(item) => setDate([item.selection])}
                moveRangeOnFirstSelection={false}
                ranges={date}
                className="date"
              />
            )}
          </div>
          <div>
            <i className="fa-solid fa-person"></i>
            <span
              onClick={() => setopenOptions(!openOptions)}
              className="hstext"
            >{`${options.adult} adult · ${options.children} children · ${options.room} room`}</span>
            {openOptions && (
              <div className="options">
                <div className="optioni">
                  <span className="optiont">Adult</span>
                  <div className="optioncounter">
                    <button
                      disabled={options.adult <= 1}
                      className="optionb"
                      onClick={() => handleOptions("adult", "d")}
                    >
                      -
                    </button>
                    <span className="optioncounter">{options.adult}</span>
                    <button
                      className="optionb"
                      onClick={() => handleOptions("adult", "i")}
                    >
                      +
                    </button>
                  </div>
                </div>
                <div className="optioni">
                  <span className="optiont">Children</span>
                  <div className="optioncounter">
                    <button
                      disabled={options.children <= 0}
                      className="optionb"
                      onClick={() => handleOptions("children", "d")}
                    >
                      -
                    </button>
                    <span className="optioncounter">{options.children}</span>
                    <button
                      className="optionb"
                      onClick={() => handleOptions("children", "i")}
                    >
                      +
                    </button>
                  </div>
                </div>
                <div className="optioni">
                  <span className="optiont">Room</span>
                  <div className="optioncounter">
                    <button
                      disabled={options.room <= 1}
                      className="optionb"
                      onClick={() => handleOptions("room", "d")}
                    >
                      -
                    </button>
                    <span className="optioncounter">{options.room}</span>
                    <button
                      className="optionb"
                      onClick={() => handleOptions("room", "i")}
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
          <div>
            <button type="submit" className="butn" onClick={findLocation}>
              Search
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Booking;
