import React, { useState } from "react";
import { useLocation } from "react-router-dom";
import "./RoomList.css";

function RoomList() {
  let location = useLocation();
  let hotels =
    location.state && location.state.hotels ? location.state.hotels : [];
  let options =
    location.state && location.state.options ? location.state.options : {};
  let numberofDays =
    location.state && location.state.numberOfDays
      ? location.state.numberOfDays
      : 0;

  let [expandedHotel, setExpandedHotel] = useState(null);

  let handleExpandClick = (hotelId) => {
    setExpandedHotel(expandedHotel === hotelId ? null : hotelId);
  };

  let handleBookNow = (hotel) => {
    // Calculate total price
    let totalPrice = numberofDays * hotel.pricePerNight * options.room; // Multiply by the number of rooms
    alert(
      `Total Price for ${numberofDays} days, ${options.room} room(s): ${totalPrice}/-`
    );
  };

  return (
    <div className="roomd">
      <h2 className="rooma">Available Rooms</h2>
      {hotels.length > 0 ? (
        <ul>
          {hotels.map((hotel) => (
            <li className="rooml" key={hotel.id}>
              <div className="hotel-header">
                <h3 className="roomna">{hotel.hotelName}</h3>
                <button
                  className="expand-button"
                  onClick={() => handleExpandClick(hotel.id)}
                >
                  {expandedHotel === hotel.id ? "Collapse" : "Expand"}
                </button>
              </div>
              {expandedHotel === hotel.id && (
                <div className="expanded-details">
                  <p className="roomlo">Location: {hotel.location}</p>
                  <img
                    src={hotel.image}
                    alt={hotel.hotelName}
                    className="roomim"
                  ></img>
                  <p className="roomco">
                    Contact Person: {hotel.contactPerson}
                  </p>
                  <p className="em">Email: {hotel.email}</p>
                  <p className="ph">Phone: {hotel.phone}</p>
                  <p className="roomnos">
                    Number of Rooms: {hotel.numberOfRooms}
                  </p>
                  <p>Price Per Night :{hotel.pricePerNight}</p>
                  <p className="roomfac">Facilities: {hotel.facilities}</p>
                  <button
                    className="book-now-button"
                    onClick={() => handleBookNow(hotel)}
                  >
                    Book Now
                  </button>
                </div>
              )}
            </li>
          ))}
        </ul>
      ) : (
        <p className="noness">No hotels found for the selected location</p>
      )}
    </div>
  );
}

export default RoomList;
