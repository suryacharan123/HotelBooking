import React from "react";
// import hotel from "../navbar.jpeg";
import "./Home.css";
import Bookingref from "../booking-references/Bookingref";
function Home() {
  return (
    <div>

    <div className="hbodys">

      <div class="home text-center">

        <div className="hbody">
          <h5 class="card-title">Welcome to Our Rooms</h5>
          <p class="card-text">Just like your home</p>
          <p>
            Wanna Experience? GET REGISTERED<br></br>
            <div className="linkss">
              <a href="/register">Register</a>
            </div>
          </p>
        </div>
      </div>
      <div>
      <Bookingref></Bookingref>
      </div>
    </div>
    </div>

  );
}

export default Home;
