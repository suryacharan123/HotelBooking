import React, { useState } from "react";
import { useForm } from "react-hook-form";
import "./Register.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function Register() {
  const { register: userRegister, handleSubmit: userHandleSubmit } = useForm();
  const { register: adminRegister, handleSubmit: adminHandleSubmit } = useForm();
  const navigate = useNavigate();

  const [error, setError] = useState("");
  const [role, setRole] = useState("user");

  const onUserRegister = async (data) => {
    try {
      const res = await axios.post(
        "http://localhost:4000/user-api/user",
        data
      );
      if (res.status === 201) {
        navigate("/login");
      } else {
        setError(res.data.message);
      }
    } catch (err) {
      setError(err.message);
    }
  };

  const onAdminRegister = async (data) => {
    try {
      const res = await axios.post(
        "http://localhost:4000/admin-api/admin",
        data
      );
      console.log(res.data); // log the response data
      if (res.status === 201) {
        navigate("/login");
      } else {
        setError(`Error: ${res.status} - ${res.statusText}`);
      }
    } catch (err) {
      if (err.response) {
        setError(`Error: ${err.response.status} - ${err.response.statusText}`);
      } else if (err.request) {
        setError(`Error: No response received from server`);
      } else {
        setError(`Error: ${err.message}`);
      }
    }
  };

  return (
    <div>
      <div className="bgs">
        <form className="forms" onSubmit={role === "user" ? userHandleSubmit(onUserRegister) : adminHandleSubmit(onAdminRegister)}>
          {error && <p className="errors">{error}</p>}
          <h1 className="heads">Register With Us</h1>
          <div>
            <label>
              <input
                type="radio"
                value="user"
                checked={role === "user"}
                onChange={() => setRole("user")}
              />
              User
            </label>
            <label>
              <input
                type="radio"
                value="admin"
                checked={role === "admin"}
                onChange={() => setRole("admin")}
              />
              Admin
            </label>
          </div>
          {role === "user" && (
            <>
              <div>
                <label htmlFor="name">Full Name</label>
                <input
                  type="text"
                  id="name"
                  {...userRegister("name")}
                  placeholder="Enter your full name"
                  required
                />
              </div>
              <div>
                <label htmlFor="username">Username</label>
                <input
                  type="text"
                  id="username"
                  {...userRegister("username")}
                  placeholder="Enter your username"
                  required
                />
              </div>
              <div>
                <label htmlFor="password">Password</label>
                <input
                  type="password"
                  id="password"
                  {...userRegister("password")}
                  placeholder="Enter your password"
                  required
                />
              </div>
              <div>
                <label htmlFor="email">Email</label>
                <input
                  type="email"
                  id="email"
                  {...userRegister("email")}
                  placeholder="Enter your email"
                  required
                />
              </div>
              <div>
                <label htmlFor="dob">Date of Birth</label>
                <input
                  type="date"
                  id="dob"
                  {...userRegister("dob")}
                  placeholder="Enter your date of birth"
                  required
                />
              </div>
            </>
          )}
          {role === "admin" && (
            <>
              <div>
                <label htmlFor="adminName">Name of Admin</label>
                <input
                  type="text"
                  id="adminName"
                  {...adminRegister("name")}
                  placeholder="Enter admin's full name"
                  required
                />
              </div>
              <div>
                <label htmlFor="adminUsername">Admin Username</label>
                <input
                  type="text"
                  id="adminUsername"
                  {...adminRegister("username")}
                  placeholder="Enter admin's username"
                  required
                />
              </div>
              <div>
                <label htmlFor="adminPassword">Admin Password</label>
                <input
                  type="password"
                  id="adminPassword"
                  {...adminRegister("password")}
                  placeholder="Enter admin's password"
                  required
                />
              </div>
            </>
          )}
          <button className="btns">Register</button>
        </form>
      </div>
    </div>
  );
}

export default Register;
