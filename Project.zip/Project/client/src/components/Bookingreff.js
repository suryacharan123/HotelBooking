import React from "react";
import hy from './images/hyderabad.jpg'
function Bookingreff({ area, state }) {
  return (
    <div>
      <div>
        <div className="refes">
          <img className="refeimg" src={hy} alt="Hyderabad"></img>
          <div className="refetitle">
            <h2>{area}</h2>
            <h2>{state}</h2>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Bookingreff;
