const exp = require("express");
const hotelApp = exp.Router();

const expressAsyncHandler = require("express-async-handler");
const  {regHotel,getHotel}  = require("../Controllers/hotel-controller");

//regHotel 

hotelApp.post("/hotels", expressAsyncHandler(regHotel));

//get hotels data 

hotelApp.get('/hotels',expressAsyncHandler(getHotel))

//export adminApp
module.exports = hotelApp;
