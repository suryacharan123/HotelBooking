const exp = require("express");
const adminApp = exp.Router();
const verifyToken = require("../Middlewares/verifyToken");

const expressAsyncHandler = require("express-async-handler");
const { loginAdmin, createAdmin } = require("../Controllers/admin-controller");

//create an admin
adminApp.post("/admin", expressAsyncHandler(createAdmin));

//login for admin
adminApp.post("/adminl", expressAsyncHandler(loginAdmin));

//export adminApp
module.exports = adminApp;
