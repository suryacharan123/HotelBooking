//create a route
const exp = require("express");
const userApp = exp.Router();
const verifyToken = require("../Middlewares/verifyToken");

const expressAsyncHandler = require("express-async-handler");

//import req handlers from controllers
const {
  getUsers,
  getuserByUsername,
  createUser,
  updateUser,
  deleteUser,
  loginUser,
} = require("../Controllers/user-controller");

//read all users
userApp.get("/users", verifyToken, expressAsyncHandler(getUsers));
//read user by id
userApp.get("/users/:username", expressAsyncHandler(getuserByUsername));
//create user
userApp.post("/user", expressAsyncHandler(createUser));
//login
userApp.post("/login", expressAsyncHandler(loginUser));
//update user
userApp.put("/user", expressAsyncHandler(updateUser));
//delete user
userApp.delete("/user/:username", expressAsyncHandler(deleteUser));
//export userapp
module.exports = userApp;
