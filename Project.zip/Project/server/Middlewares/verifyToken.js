require("dotenv").config()

const jwt=require("jsonwebtoken")
function verifyToken(req,res,next){
    //token verification logic
    const bearerToken=req.headers.authorization;
    //get bearer 
    if(bearerToken){
        const token=bearerToken.split(' ')[1]
        let decoded=jwt.verify(token,process.env.SECRET_KEY)
        console.log(decoded)
        next()
    }else{
        res.status(403).send({message:"unauthorised access"})
    }
}

module.exports=verifyToken;