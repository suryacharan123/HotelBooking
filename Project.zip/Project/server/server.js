//create express app
const exp = require("express");
const app = exp();
const path = require("path");
const connectdb=require('./db')
const cors = require("cors");
connectdb()
//connect to react app
// app.use(exp.static(path.join(__dirname, "../client/build")));
app.use(cors());
//configure environment variables
require("dotenv").config();
//add body prasing middleware
app.use(exp.json());

const userApp = require("./APIs/user-api");
//forward req  to userapp when path starts with '/user-api'
app.use("/user-api", userApp);

const adminApp=require('./APIs/admin-api');
app.use('/admin-api',adminApp)
//error handler

const hotelApp=require("./APIs/hotels-api");
app.use('/hotel-api',hotelApp)

app.use((err, req, res, next) => {
  res.send({ message: "error occoured", payload: err.message });
});
//assign port number
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`web server listening on port ${PORT}`));
