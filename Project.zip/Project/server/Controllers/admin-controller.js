const Admin = require("../models/Admin");
const bcryptjs = require("bcryptjs");
const jwt=require("jsonwebtoken")

const createAdmin = async (req, res, next) => {
  try {
    let hashedPass = await bcryptjs.hash(req.body.password, 5);
    req.body.password = hashedPass;
    let newAdmin = await Admin.create(req.body);
    res.status(201).send({ message: "Admin Created", payload: newAdmin });
  } catch (error) {
    next(error); // Pass the error to the error handler middleware
  }
};

const loginAdmin = async (req, res, next) => {
  try {
    const userCred = req.body;
    console.log(userCred)
    let user = await Admin.findOne({ username: userCred.username });
    console.log('----')
    console.log(user)
    if (user === null) {
      return res.status(401).send({ message: "Invalid Adminname" });
    }
    const result = await bcryptjs.compare(userCred.password, user.password);
    if (result === false) {
      return res.status(401).send({ message: "Invalid Password" });
    }
    const signedToken = jwt.sign(
      { username: user.username },
      process.env.SECRET_KEY,
      { expiresIn: "1d" }
    );
    res.send({ message: "Login successful", token: signedToken, user: user });
  } catch (error) {
    next(error); // Pass the error to the error handler middleware
  }
};
module.exports = {
  loginAdmin,
  createAdmin,
};
