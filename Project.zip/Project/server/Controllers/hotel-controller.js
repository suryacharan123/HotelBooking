const Hotel=require('../models/hotels')

const regHotel=async(req,res,next)=>{
    try{
        let newReg= await Hotel.create(req.body);
        res.status(201).send({message:"Hotel Registered",payload:newReg})
    }
    catch(error){
        next(error)
    }
}

const getHotel=async(req,res,next)=>{
    try{
        let hotelList=await Hotel.find()
        res.status(200).send({message:"Data received",payload:hotelList});
    }catch{
        
    }
}
module.exports={
    regHotel,getHotel
}