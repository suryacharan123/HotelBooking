const User = require("../models/User");

//import user model
const jwt = require("jsonwebtoken");
const bcryptjs = require("bcryptjs");
const getUsers = async (req, res) => {
  // res.send({ message: "All Users Data" });
  const usersList = await User.find();
  res.status(200).send({ message: "users", payload: usersList });
};
const getuserByUsername = (req, res) => {
  res.send({ message: "one user" });
};

const createUser = async (req, res) => {
  //create user create()=create document + save in collection
  //if user existed
  const existingUser = await User.findOne({ username: req.body.username });
  if (existingUser !== null) {
    return res.status(200).send({ message: "User already existed" });
  }
  //if no user existed
  //hash the password
  let hashedPass = await bcryptjs.hash(req.body.password, 5);
  //replace the password with hash password
  req.body.password = hashedPass;
  let newUser = await User.create(req.body);
  res.status(201).send({ message: "User Created", payload: newUser });
};

//to login
const loginUser = async (req, res) => {
  const userCred = req.body;
  //check username
  let user = await User.findOne({ username: userCred.username });
  if (user === null) {
    return res.status(201).send({ message: "Invalid Username" });
  }

  //if username is found compare password
  const result = await bcryptjs.compare(userCred.password, user.password);
  if (result === false) {
    return res.status(201).send({ message: "invalid Password" });
  }
  //create jwt token and sign it
  const signedToken = jwt.sign(
    { username: user.username },
    process.env.SECRET_KEY,
    { expiresIn: "1d" }
  );
  res.status(200).send({ message: "login successfull", token: signedToken, user: user });
};
const updateUser = async (req, res) => {
  let result = await User.findOneAndUpdate(
    { username: req.body.username },
    { ...req.body }
  );
  res.status(201).send({ message: "User updated", payload: result });
};

const deleteUser = async (req, res) => {
  let deletedRes = await User.deleteOne({ username: "ravi" });

  res.send({ message: "User deleted", payload: deletedRes });
};
//export

module.exports = {
  getUsers,
  getuserByUsername,
  createUser,
  updateUser,
  deleteUser,
  loginUser,
};
