const mongoose=require('mongoose')

const userSchema = new mongoose.Schema({
    name:{
      type:String,
      required:true
    },
    username: {
      type: String,
      required: [true, "username is required"],
      minLength: [4, "there must be atleast 4 characters"],
    },
    password: {
      type: String,
      required: [true, "password is required"],
    },
    email: String,
    dob: Date,
  });

  module.exports=mongoose.model('User',userSchema)
  
  