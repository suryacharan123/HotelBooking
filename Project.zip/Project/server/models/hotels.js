const mongoose=require('mongoose')
const hotelSchema = new mongoose.Schema({
    hotelName:{
        type:String,
        required:true,
    },
    location:{
        type:String,
        required:true,
    },
    contactPerson:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    phone:{
        type:Number,
        required:true
    },
    numberOfRooms:{
        type:String,
        required:true
    },
    pricePerNight:{
        type:String,
        required:true
    },
    facilities:{
        type:String,
        required:true
    }
  })

  module.exports=mongoose.model('Hotel',hotelSchema)