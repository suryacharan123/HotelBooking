//import mongoose
const mongoose = require("mongoose");

//connect mongoose
const connectdb=()=>{
  mongoose
  .connect(
'mongodb+srv://practice:practice@cluster0.f2fegap.mongodb.net/samplects?retryWrites=true&w=majority&appName=Cluster0'  )
  .then(() => console.log("db connection success"))
  .catch((err) => console.log("error in db connect", err));

}

module.exports=connectdb